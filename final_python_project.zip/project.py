
print("Welcome to the guessing game")
import random
number=input("enter your number between 1 to 6 : ")
num=int(number)
score=0
a=random.randint(1,6)

k=input("click enter to continue and *>>enter to exit")
while k!="*":
    print("your number is:",number)
    print("the computer's number is", a)
    if num==a:
        score=score+1
        print("you won")
        print("your score is",score)
    else:
        print("no matching has been found")
        print("your score is still",score)
    print()

    k = input("click enter to continue and * to exit")
    a = random.randint(1,6)
print()
print("The game has been ended")
print("your final score is: "+str(score))
print("Thank you for playing")




